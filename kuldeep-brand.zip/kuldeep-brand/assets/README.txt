Drop your photos here — see README for filenames
